<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Staff';

// Check if the user is an admin or staff
$role = $_SESSION['role'] ?? 'staff'; // default to 'staff' if no role is set
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <!-- Back Button -->
    <a href="dashboard_<?= $role ?>.php" class="btn btn-secondary mb-4">&larr; Back to Dashboard</a>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Dashboard</h4>
        </div>
        <div class="card-body">
            <h5>Welcome, <?= htmlspecialchars($username) ?>!</h5>

            <?php if ($role === 'admin'): ?>
                <!-- If the user is an admin, show the Report History link -->
                <a href="view_reports.php" class="btn btn-primary mb-4">📜 View Report History</a>
            <?php elseif ($role === 'staff'): ?>
                <!-- If the user is staff, show the Upload Report Form link -->
                <a href="report_form.php" class="btn btn-primary mb-4">📋 Upload Report Form</a>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
